// src/models/kodeBiayaModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const kodeBiayaSchema = new Schema({
  kode: {
    type: String,
    required: true,
    unique: true 
  },
  uraian: {
    type: String,
    required: true
  },
  jenis: {
    type: String,
    required: true,
    enum: ['Penambah', 'Pengurang', 'Pindahan'] // Samakan dengan Kode Kas
  }
}, { timestamps: true });

// Perbaiki baris ini
module.exports = mongoose.models.KodeBiaya || mongoose.model('KodeBiaya', kodeBiayaSchema);