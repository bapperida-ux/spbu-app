// src/models/transaksiKasModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// 1. Ganti nama skema menjadi 'transaksiKasSchema'
const transaksiKasSchema = new Schema({
  // 2. Ganti nama field menjadi 'kodeKas'
  kodeKas: {
    type: String,
    required: true
  },
  tanggal: {
    type: Date,
    required: true
  },
  total: {
    type: Number,
    required: true
  },
  keterangan: {
    type: String,
    trim: true
  }
}, { timestamps: true });

// 3. Ganti nama model menjadi 'TransaksiKas' dan tambahkan perbaikan OverwriteModelError
module.exports = mongoose.models.TransaksiKas || mongoose.model('TransaksiKas', transaksiKasSchema);