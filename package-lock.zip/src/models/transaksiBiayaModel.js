// src/models/transaksiBiayaModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const transaksiBiayaSchema = new Schema({
  // Kita simpan HANYA kodenya
  kodeBiaya: {
    type: String,
    required: true
  },
  tanggal: {
    type: Date,
    required: true
  },
  total: {
    type: Number,
    required: true
  },
  keterangan: {
    type: String,
    trim: true
  }
}, { timestamps: true });

// Ganti baris ini untuk memperbaiki error OverwriteModel
module.exports = mongoose.models.TransaksiBiaya || mongoose.model('TransaksiBiaya', transaksiBiayaSchema);