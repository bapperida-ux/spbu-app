// src/models/walletModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const walletSchema = new Schema({
  balance: {
    type: Number,
    default: 0
  },
  lastChange: {
    type: String,
    default: '+0.0% than last week'
  }
});

// Kita buat hanya 1 dokumen wallet saja
module.exports = mongoose.model('Wallet', walletSchema);