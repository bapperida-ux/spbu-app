// src/models/kodeKasModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const kodeKasSchema = new Schema({
  kode: {
    type: String,
    required: true,
    unique: true 
  },
  uraian: {
    type: String,
    required: true
  },
  jenis: {
    type: String,
    required: true,
    enum: ['Penambah', 'Pengurang', 'Pindahan']
  }
}, { timestamps: true });

// Perbaiki baris ini
module.exports = mongoose.models.KodeKas || mongoose.model('KodeKas', kodeKasSchema);