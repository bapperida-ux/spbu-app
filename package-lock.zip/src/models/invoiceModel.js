// src/models/invoiceModel.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const invoiceSchema = new Schema({
  clientName: String,
  amount: Number,
  status: {
    type: String,
    enum: ['Paid', 'Unpaid', 'Sent'], // Hanya boleh diisi ini
    default: 'Sent'
  }
}, { timestamps: true }); // timestamps: true (menambah createdAt & updatedAt)

module.exports = mongoose.model('Invoice', invoiceSchema);