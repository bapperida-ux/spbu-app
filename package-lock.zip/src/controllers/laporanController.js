// src/controllers/laporanController.js
const TransaksiKas = require('../models/transaksiKasModel');
const TransaksiBiaya = require('../models/transaksiBiayaModel');
const KodeKas = require('../models/kodeKasModel');
const KodeBiaya = require('../models/kodeBiayaModel');

// Helper function (tetap sama)
async function getKodeMap(model) {
  const items = await model.find({});
  const map = new Map();
  items.forEach(item => map.set(item.kode, { uraian: item.uraian, jenis: item.jenis }));
  return map;
}

// Helper function (tetap sama)
async function calculateSaldoAwal(startDate) {
  // ... (Kode calculateSaldoAwal tetap sama seperti sebelumnya) ...
  let saldo = 0;
  const kodeKasMap = await getKodeMap(KodeKas);
  const kodeBiayaMap = await getKodeMap(KodeBiaya);

  const kasSebelum = await TransaksiKas.find({ tanggal: { $lt: startDate } });
  kasSebelum.forEach(trx => {
    const detailKode = kodeKasMap.get(trx.kodeKas);
    if (detailKode) {
      if (detailKode.jenis === 'Penambah') saldo += trx.total;
      else if (detailKode.jenis === 'Pengurang' || detailKode.jenis === 'Pindahan') saldo -= trx.total;
    }
  });

  const biayaSebelum = await TransaksiBiaya.find({ tanggal: { $lt: startDate } });
  biayaSebelum.forEach(trx => {
    const detailKode = kodeBiayaMap.get(trx.kodeBiaya);
    if (detailKode) {
      if (detailKode.jenis === 'Penambah') saldo += trx.total;
      else saldo -= trx.total;
    }
  });
  return saldo;
}

// Mengambil Laporan Kas (tetap sama)
exports.getLaporanKas = async (req, res) => {
 // ... (Kode getLaporanKas tetap sama seperti sebelumnya) ...
  try {
    const { startDate, endDate } = req.query;
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const saldoAwal = await calculateSaldoAwal(start);
    const kodeKasMap = await getKodeMap(KodeKas);

    const transaksi = await TransaksiKas.find({
      tanggal: { $gte: start, $lte: end }
    }).sort({ tanggal: 1, createdAt: 1 });

    const laporanData = transaksi.map(trx => {
      const detailKode = kodeKasMap.get(trx.kodeKas);
      return {
        _id: trx._id, tanggal: trx.tanggal, kode: trx.kodeKas,
        uraian: detailKode ? detailKode.uraian : 'Kode Tidak Ditemukan',
        jenis: detailKode ? detailKode.jenis : 'Unknown',
        total: trx.total, keterangan: trx.keterangan,
      };
    });
    res.json({ saldoAwal, data: laporanData });
  } catch (err) { res.status(500).json({ error: err.message }); }
};

// Mengambil Laporan Biaya (tetap sama)
exports.getLaporanBiaya = async (req, res) => {
 // ... (Kode getLaporanBiaya tetap sama seperti sebelumnya) ...
  try {
    const { startDate, endDate } = req.query;
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const saldoAwal = await calculateSaldoAwal(start);
    const kodeBiayaMap = await getKodeMap(KodeBiaya);

    const transaksi = await TransaksiBiaya.find({
      tanggal: { $gte: start, $lte: end }
    }).sort({ tanggal: 1, createdAt: 1 });

    const laporanData = transaksi.map(trx => {
      const detailKode = kodeBiayaMap.get(trx.kodeBiaya);
      return {
        _id: trx._id, tanggal: trx.tanggal, kode: trx.kodeBiaya,
        uraian: detailKode ? detailKode.uraian : 'Kode Tidak Ditemukan',
        jenis: detailKode ? detailKode.jenis : 'Unknown',
        total: trx.total, keterangan: trx.keterangan,
      };
    });
    res.json({ saldoAwal, data: laporanData });
  } catch (err) { res.status(500).json({ error: err.message }); }
};

// ===================================
// === FUNGSI BARU: LAPORAN MARGIN ===
// ===================================
exports.getLaporanMargin = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999); // Akhir hari

    const kodeKasMap = await getKodeMap(KodeKas);
    const kodeBiayaMap = await getKodeMap(KodeBiaya);

    // 1. Ambil SEMUA data Biaya & Kas untuk periode filter
    const transactionsBiayaAll = await TransaksiBiaya.find({
        tanggal: { $gte: start, $lte: end }
    });
    const transactionsKasAll = await TransaksiKas.find({
        tanggal: { $gte: start, $lte: end }
    });

    // 2. Proses Data Biaya (Exclude 'isi kas')
    const processedBiaya = transactionsBiayaAll
      .filter(tx => {
        const detailKode = kodeBiayaMap.get(tx.kodeBiaya);
        // Pastikan detailKode ada sebelum mengakses uraian
        const uraianLower = detailKode ? String(detailKode.uraian).trim().toLowerCase() : "";
        return uraianLower !== 'isi kas'; // Filter exclude 'isi kas'
      })
      .map(tx => {
          const detailKode = kodeBiayaMap.get(tx.kodeBiaya);
          const jenis = detailKode ? detailKode.jenis : 'Unknown';
          return {
              tanggal: tx.tanggal,
              kode: tx.kodeBiaya,
              uraian: detailKode ? detailKode.uraian : 'Kode Biaya Tidak Ditemukan',
              uangMasuk: jenis === 'Penambah' ? tx.total : 0, // Misal refund biaya
              uangKeluar: jenis === 'Pengurang' || jenis === 'Pindahan' ? tx.total : 0, // Pengeluaran
              keterangan: tx.keterangan || '',
              isMargin: false // Tandai ini bukan margin
          };
      });

    // 3. Proses Data Margin (Hanya 'margin' dari Kas)
    const processedMargin = transactionsKasAll
      .filter(tx => {
          const detailKode = kodeKasMap.get(tx.kodeKas);
          const uraianLower = detailKode ? String(detailKode.uraian).trim().toLowerCase() : "";
          return uraianLower === 'margin'; // Filter hanya 'margin'
      })
      .map(tx => ({
          tanggal: tx.tanggal,
          kode: tx.kodeKas,
          uraian: 'Margin Harian', // Ubah uraian
          uangMasuk: tx.total, // Margin selalu masuk
          uangKeluar: 0,
          keterangan: tx.keterangan || '',
          isMargin: true // Tandai ini margin
      }));

    // 4. Gabungkan dan Urutkan
    const combinedData = [...processedBiaya, ...processedMargin];
    combinedData.sort((a, b) => {
        const dateA = new Date(a.tanggal);
        const dateB = new Date(b.tanggal);
        const dateComparison = dateA - dateB;
        if (dateComparison !== 0) return dateComparison;
        // Jika tanggal sama, margin di akhir
        if (a.isMargin && !b.isMargin) return 1;
        if (!a.isMargin && b.isMargin) return -1;
        return 0; // Urutan asli jika sama-sama biaya atau sama-sama margin (jarang terjadi)
    });

    // Kirim data yang sudah digabung (saldo awal akan 0, dihitung di frontend)
    res.json({ saldoAwal: 0, data: combinedData });

  } catch (err) {
    console.error("Error di getLaporanMargin:", err); // Log error
    res.status(500).json({ error: err.message });
  }
};