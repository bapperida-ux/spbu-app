// src/controllers/dashboardController.js
const Invoice = require('../models/invoiceModel');
const Wallet = require('../models/walletModel');

// Fungsi untuk mengambil data 4 card di atas
exports.getDashboardStats = async (req, res) => {
  try {
    // Menghitung jumlah dokumen berdasarkan status
    const totalInvoices = await Invoice.countDocuments({});
    const paidInvoices = await Invoice.countDocuments({ status: 'Paid' });
    const unpaidInvoices = await Invoice.countDocuments({ status: 'Unpaid' });
    const totalSent = await Invoice.countDocuments({ status: 'Sent' });

    // Kirim sebagai JSON
    res.json({
      totalInvoices,  // e.g., 2478
      paidInvoices,   // e.g., 983
      unpaidInvoices, // e.g., 1256
      totalSent       // e.g., 652
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Fungsi untuk mengambil saldo dompet
exports.getWalletBalance = async (req, res) => {
  try {
    // Cari 1 dokumen wallet. Jika tidak ada, buat baru.
    let wallet = await Wallet.findOne();
    if (!wallet) {
      wallet = await Wallet.create({ balance: 824571.93, lastChange: '+0.8% than last week' });
    }

    res.json(wallet); // Kirim data wallet
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};