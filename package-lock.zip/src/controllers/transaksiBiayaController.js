// src/controllers/transaksiBiayaController.js
const TransaksiBiaya = require('../models/transaksiBiayaModel');

// Membuat Transaksi Biaya Baru
exports.createTransaksiBiaya = async (req, res) => {
  try {
    const { kodeBiaya, tanggal, total, keterangan } = req.body;
    const newTransaksi = new TransaksiBiaya({ kodeBiaya, tanggal, total, keterangan });
    await newTransaksi.save();
    res.status(201).json(newTransaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Mendapatkan Semua Transaksi Biaya (HANYA HARI INI)
exports.getAllTransaksiBiaya = async (req, res) => {
  try {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date();
    end.setHours(23, 59, 59, 999);

    const allTransaksi = await TransaksiBiaya.find({
      tanggal: { $gte: start, $lte: end }
    }).sort({ createdAt: -1 });
    res.json(allTransaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// --- FUNGSI BARU UNTUK EDIT/DELETE ---

// Mendapatkan 1 Transaksi by ID
exports.getTransaksiBiayaById = async (req, res) => {
  try {
    const { id } = req.params;
    const transaksi = await TransaksiBiaya.findById(id);
    if (!transaksi) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(transaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Mengupdate 1 Transaksi by ID
exports.updateTransaksiBiaya = async (req, res) => {
  try {
    const { id } = req.params;
    const { kodeBiaya, tanggal, total, keterangan } = req.body;

    const updated = await TransaksiBiaya.findByIdAndUpdate(
      id,
      { kodeBiaya, tanggal, total, keterangan },
      { new: true, runValidators: true }
    );
    if (!updated) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Menghapus 1 Transaksi by ID
exports.deleteTransaksiBiaya = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await TransaksiBiaya.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json({ message: 'Transaksi berhasil dihapus', id: deleted._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};