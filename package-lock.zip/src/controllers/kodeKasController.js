// src/controllers/kodeKasController.js
const KodeKas = require('../models/kodeKasModel');

// 1. Membuat Kode Kas Baru (Sudah ada)
exports.createKodeKas = async (req, res) => {
  try {
    const { kode, uraian, jenis } = req.body;
    const existing = await KodeKas.findOne({ kode });
    if (existing) {
      return res.status(400).json({ error: 'Kode kas sudah ada. Tidak boleh duplikat.' });
    }
    const newKodeKas = new KodeKas({ kode, uraian, jenis });
    await newKodeKas.save();
    res.status(201).json(newKodeKas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 2. Mendapatkan Semua Kode Kas (Sudah ada)
exports.getAllKodeKas = async (req, res) => {
  try {
    const allKodeKas = await KodeKas.find({}).sort({ kode: 1 });
    res.json(allKodeKas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 3. Menghapus Kode Kas (Sudah ada)
exports.deleteKodeKas = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await KodeKas.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json({ message: 'Data berhasil dihapus', id: deleted._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. MENDAPATKAN 1 KODE KAS BY ID (BARU)
exports.getKodeKasById = async (req, res) => {
  try {
    const { id } = req.params;
    const kodeKas = await KodeKas.findById(id);
    if (!kodeKas) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(kodeKas); // Kirim data spesifik
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 5. MENGUPDATE 1 KODE KAS BY ID (BARU)
exports.updateKodeKas = async (req, res) => {
  try {
    const { id } = req.params;
    const { kode, uraian, jenis } = req.body;

    // Cek duplikasi kode (pastikan kode baru tidak dipakai oleh data LAIN)
    const existing = await KodeKas.findOne({ kode: kode, _id: { $ne: id } });
    if (existing) {
      return res.status(400).json({ error: 'Kode kas tersebut sudah dipakai data lain.' });
    }

    const updatedKodeKas = await KodeKas.findByIdAndUpdate(
      id,
      { kode, uraian, jenis },
      { new: true, runValidators: true } // 'new: true' agar mengembalikan data baru
    );

    if (!updatedKodeKas) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(updatedKodeKas); // Kirim data yang sudah di-update
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};