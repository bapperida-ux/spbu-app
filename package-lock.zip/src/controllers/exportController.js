// src/controllers/exportController.js
const ExcelJS = require('exceljs');
const { getLaporanKasData, getLaporanBiayaData, getLaporanMarginData } = require('./laporanHelper'); // Helper (akan kita buat)

// --- Helper Styling ---
const headerStyle = {
  font: { bold: true, color: { argb: 'FFFFFFFF' } }, // Putih Tebal
  fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } }, // Biru Gelap Sidebar
  alignment: { vertical: 'middle', horizontal: 'center' },
  border: {
    top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' }
  }
};
const totalStyle = {
  font: { bold: true },
  alignment: { horizontal: 'right' },
  border: { top: { style: 'double' } }
};
const rupiahFormat = '_-[$Rp-421]* #,##0_-;\\-[$Rp-421]* #,##0_-;_-"-"_-;_-@_-'; // Format Akuntansi Rupiah

// --- Fungsi Ekspor Utama ---

exports.exportKasToExcel = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const { saldoAwal, data } = await getLaporanKasData(startDate, endDate); // Gunakan helper
    
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'SPBU Kolongan App';
    workbook.lastModifiedBy = 'SPBU Kolongan App';
    workbook.created = new Date();
    workbook.modified = new Date();
    
    const worksheet = workbook.addWorksheet('Laporan Kas');

    // Judul Laporan
    worksheet.mergeCells('A1:G1');
    worksheet.getCell('A1').value = `Laporan Kas SPBU Kolongan`;
    worksheet.getCell('A1').style = { font: { size: 16, bold: true }, alignment: { horizontal: 'center' } };
    worksheet.mergeCells('A2:G2');
    worksheet.getCell('A2').value = `Periode: ${new Date(startDate).toLocaleDateString('id-ID')} s/d ${new Date(endDate).toLocaleDateString('id-ID')}`;
    worksheet.getCell('A2').style = { font: { italic: true }, alignment: { horizontal: 'center' } };
    worksheet.addRow([]); // Baris kosong

    // Header Tabel
    const headers = ['Tanggal', 'Kode', 'Uraian', 'Uang Masuk (Rp)', 'Uang Keluar (Rp)', 'Sisa Saldo (Rp)', 'Keterangan'];
    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell) => { cell.style = headerStyle; });

    // Baris Saldo Awal
    let currentRow = 5; // Mulai data setelah header dan baris kosong
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`);
    worksheet.getCell(`A${currentRow}`).value = 'SALDO AWAL';
    worksheet.getCell(`A${currentRow}`).style = { font: { bold: true, italic: true }};
    worksheet.getCell(`F${currentRow}`).value = saldoAwal;
    worksheet.getCell(`F${currentRow}`).numFmt = rupiahFormat;
    worksheet.getCell(`F${currentRow}`).style = { font: { bold: true }, alignment: { horizontal: 'right' } };
    worksheet.getCell(`G${currentRow}`).value = `Saldo sblm ${new Date(startDate).toLocaleDateString('id-ID')}`;
    worksheet.getCell(`G${currentRow}`).style = { font: { italic: true } };
    currentRow++;

    // Data Transaksi
    let currentSaldo = saldoAwal;
    let totalMasuk = 0;
    let totalKeluar = 0;
    data.forEach(trx => {
      let uangMasuk = 0;
      let uangKeluar = 0;
      if (trx.jenis === 'Penambah') {
        uangMasuk = trx.total;
        currentSaldo += trx.total;
        totalMasuk += trx.total;
      } else if (trx.jenis === 'Pengurang' || trx.jenis === 'Pindahan') {
        uangKeluar = trx.total;
        currentSaldo -= trx.total;
        totalKeluar += trx.total;
      }
      
      const rowData = [
        new Date(trx.tanggal), // Simpan sebagai Date agar bisa diformat Excel
        trx.kode,
        trx.uraian,
        uangMasuk > 0 ? uangMasuk : '',
        uangKeluar > 0 ? uangKeluar : '', // Simpan positif, format excel yg urus minus
        currentSaldo,
        trx.keterangan || ''
      ];
      const dataRow = worksheet.addRow(rowData);
      
      // Styling per sel
      dataRow.getCell(1).numFmt = 'dd/mm/yyyy'; // Format Tanggal
      dataRow.getCell(4).numFmt = rupiahFormat;
      dataRow.getCell(5).numFmt = rupiahFormat;
      dataRow.getCell(6).numFmt = rupiahFormat;
      dataRow.getCell(6).style.font = { bold: true }; // Saldo bold
      dataRow.getCell(6).style.alignment = { horizontal: 'right' };
      dataRow.getCell(4).style.alignment = { horizontal: 'right' };
      dataRow.getCell(5).style.alignment = { horizontal: 'right' };

      currentRow++;
    });

    // Baris Total
    worksheet.addRow([]); // Baris kosong sebelum total
    const totalRow = worksheet.addRow(['', '', 'TOTAL PERIODE', totalMasuk, totalKeluar, '', '']);
    totalRow.getCell(3).style = totalStyle;
    totalRow.getCell(4).style = totalStyle;
    totalRow.getCell(4).numFmt = rupiahFormat;
    totalRow.getCell(5).style = totalStyle;
    totalRow.getCell(5).numFmt = rupiahFormat;
    totalRow.getCell(4).font = { bold: true, color: { argb: 'FF27AE60' } }; // Hijau
    totalRow.getCell(5).font = { bold: true, color: { argb: 'FFE74C3C' } }; // Merah

    // Atur Lebar Kolom
    worksheet.columns = [
      { key: 'A', width: 12 }, { key: 'B', width: 10 }, { key: 'C', width: 35 },
      { key: 'D', width: 18 }, { key: 'E', width: 18 }, { key: 'F', width: 18 },
      { key: 'G', width: 30 }
    ];

    // Pengaturan Print (Opsional)
    worksheet.pageSetup.orientation = 'landscape';
    worksheet.pageSetup.fitToPage = true;
    worksheet.pageSetup.fitToWidth = 1;
    worksheet.pageSetup.fitToHeight = 0;

    // Set Header untuk Download
    const fileName = `Laporan_Kas_${startDate}_sd_${endDate}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);

    // Tulis ke response
    await workbook.xlsx.write(res);
    res.end();

  } catch (error) {
    console.error('Error exporting Kas to Excel:', error);
    res.status(500).send('Gagal mengekspor laporan Kas');
  }
};

// --- Fungsi Ekspor Biaya (Mirip Kas) ---
exports.exportBiayaToExcel = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const { saldoAwal, data } = await getLaporanBiayaData(startDate, endDate); // Gunakan helper
    
    const workbook = new ExcelJS.Workbook();
    // ... (Workbook properties sama) ...
    workbook.creator = 'SPBU Kolongan App'; workbook.created = new Date(); workbook.modified = new Date();

    const worksheet = workbook.addWorksheet('Laporan Biaya');

    // Judul Laporan
    worksheet.mergeCells('A1:G1'); worksheet.getCell('A1').value = `Laporan Biaya SPBU Kolongan`; worksheet.getCell('A1').style = { font: { size: 16, bold: true }, alignment: { horizontal: 'center' } };
    worksheet.mergeCells('A2:G2'); worksheet.getCell('A2').value = `Periode: ${new Date(startDate).toLocaleDateString('id-ID')} s/d ${new Date(endDate).toLocaleDateString('id-ID')}`; worksheet.getCell('A2').style = { font: { italic: true }, alignment: { horizontal: 'center' } };
    worksheet.addRow([]);

    // Header Tabel
    const headers = ['Tanggal', 'Kode', 'Uraian', 'Uang Masuk (Rp)', 'Uang Keluar (Rp)', 'Sisa Saldo (Rp)', 'Keterangan'];
    const headerRow = worksheet.addRow(headers); headerRow.eachCell((cell) => { cell.style = headerStyle; });

    // Baris Saldo Awal
    let currentRow = 5;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`); worksheet.getCell(`A${currentRow}`).value = 'SALDO AWAL'; worksheet.getCell(`A${currentRow}`).style = { font: { bold: true, italic: true }};
    worksheet.getCell(`F${currentRow}`).value = saldoAwal; worksheet.getCell(`F${currentRow}`).numFmt = rupiahFormat; worksheet.getCell(`F${currentRow}`).style = { font: { bold: true }, alignment: { horizontal: 'right' } };
    worksheet.getCell(`G${currentRow}`).value = `Saldo sblm ${new Date(startDate).toLocaleDateString('id-ID')}`; worksheet.getCell(`G${currentRow}`).style = { font: { italic: true } };
    currentRow++;

    // Data Transaksi
    let currentSaldo = saldoAwal; let totalMasuk = 0; let totalKeluar = 0;
    data.forEach(trx => {
      let uangMasuk = 0; let uangKeluar = 0;
      // Logika jenis biaya
      if (trx.jenis === 'Penambah') {
        uangMasuk = trx.total; currentSaldo += trx.total; totalMasuk += trx.total;
      } else { // Pengurang / Pindahan
        uangKeluar = trx.total; currentSaldo -= trx.total; totalKeluar += trx.total;
      }
      
      const rowData = [ new Date(trx.tanggal), trx.kode, trx.uraian, uangMasuk > 0 ? uangMasuk : '', uangKeluar > 0 ? uangKeluar : '', currentSaldo, trx.keterangan || '' ];
      const dataRow = worksheet.addRow(rowData);
      
      dataRow.getCell(1).numFmt = 'dd/mm/yyyy'; dataRow.getCell(4).numFmt = rupiahFormat; dataRow.getCell(5).numFmt = rupiahFormat; dataRow.getCell(6).numFmt = rupiahFormat;
      dataRow.getCell(6).style.font = { bold: true }; dataRow.getCell(6).style.alignment = { horizontal: 'right' };
      dataRow.getCell(4).style.alignment = { horizontal: 'right' }; dataRow.getCell(5).style.alignment = { horizontal: 'right' };
      currentRow++;
    });

    // Baris Total
    worksheet.addRow([]);
    const totalRow = worksheet.addRow(['', '', 'TOTAL PERIODE', totalMasuk, totalKeluar, '', '']);
    totalRow.getCell(3).style = totalStyle; totalRow.getCell(4).style = totalStyle; totalRow.getCell(4).numFmt = rupiahFormat;
    totalRow.getCell(5).style = totalStyle; totalRow.getCell(5).numFmt = rupiahFormat;
    totalRow.getCell(4).font = { bold: true, color: { argb: 'FF27AE60' } }; totalRow.getCell(5).font = { bold: true, color: { argb: 'FFE74C3C' } };

    // Atur Lebar Kolom & Print Setup
    worksheet.columns = [ { key: 'A', width: 12 }, { key: 'B', width: 10 }, { key: 'C', width: 35 }, { key: 'D', width: 18 }, { key: 'E', width: 18 }, { key: 'F', width: 18 }, { key: 'G', width: 30 } ];
    worksheet.pageSetup.orientation = 'landscape'; worksheet.pageSetup.fitToPage = true; worksheet.pageSetup.fitToWidth = 1; worksheet.pageSetup.fitToHeight = 0;

    // Set Header & Tulis ke response
    const fileName = `Laporan_Biaya_${startDate}_sd_${endDate}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
    await workbook.xlsx.write(res);
    res.end();

  } catch (error) { console.error('Error exporting Biaya to Excel:', error); res.status(500).send('Gagal mengekspor laporan Biaya'); }
};

// --- Fungsi Ekspor Margin ---
exports.exportMarginToExcel = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const { saldoAwal, data } = await getLaporanMarginData(startDate, endDate); // Gunakan helper

    const workbook = new ExcelJS.Workbook();
    // ... (Workbook properties) ...
    workbook.creator = 'SPBU Kolongan App'; workbook.created = new Date(); workbook.modified = new Date();
    
    const worksheet = workbook.addWorksheet('Buku Margin');

    // Judul Laporan
    worksheet.mergeCells('A1:G1'); worksheet.getCell('A1').value = `Buku Margin SPBU Kolongan`; worksheet.getCell('A1').style = { font: { size: 16, bold: true }, alignment: { horizontal: 'center' } };
    worksheet.mergeCells('A2:G2'); worksheet.getCell('A2').value = `Periode: ${new Date(startDate).toLocaleDateString('id-ID')} s/d ${new Date(endDate).toLocaleDateString('id-ID')}`; worksheet.getCell('A2').style = { font: { italic: true }, alignment: { horizontal: 'center' } };
    worksheet.addRow([]);

    // Header Tabel
    const headers = ['Tanggal', 'Kode', 'Uraian', 'Uang Masuk (Rp)', 'Uang Keluar (Rp)', 'Sisa Saldo (Rp)', 'Keterangan'];
    const headerRow = worksheet.addRow(headers); headerRow.eachCell((cell) => { cell.style = headerStyle; });

    // Baris Saldo Awal (selalu 0 untuk margin)
    let currentRow = 5;
    worksheet.mergeCells(`A${currentRow}:E${currentRow}`); worksheet.getCell(`A${currentRow}`).value = 'SALDO AWAL PERIODE'; worksheet.getCell(`A${currentRow}`).style = { font: { bold: true, italic: true }};
    worksheet.getCell(`F${currentRow}`).value = 0; // Saldo awal periode margin = 0
    worksheet.getCell(`F${currentRow}`).numFmt = rupiahFormat; worksheet.getCell(`F${currentRow}`).style = { font: { bold: true }, alignment: { horizontal: 'right' } };
    currentRow++;

    // Data Transaksi (Biaya & Margin)
    let currentSaldo = 0; let totalMasuk = 0; let totalKeluar = 0;
    data.forEach(item => {
      let uangMasuk = 0; let uangKeluar = 0; let saldoChange = 0;
      
      if (item.isMargin) {
          uangMasuk = item.uangMasuk; saldoChange = item.uangMasuk; totalMasuk += item.uangMasuk;
      } else { // Biaya
          if (item.uangMasuk > 0) { // Refund
              uangMasuk = item.uangMasuk; saldoChange = item.uangMasuk; totalMasuk += item.uangMasuk;
          }
          if (item.uangKeluar > 0) { // Pengeluaran
              uangKeluar = item.uangKeluar; saldoChange = -item.uangKeluar; totalKeluar += item.uangKeluar;
          }
      }
      currentSaldo += saldoChange;

      const rowData = [ new Date(item.tanggal), item.kode, item.uraian, uangMasuk > 0 ? uangMasuk : '', uangKeluar > 0 ? uangKeluar : '', currentSaldo, item.keterangan || '' ];
      const dataRow = worksheet.addRow(rowData);
      
      dataRow.getCell(1).numFmt = 'dd/mm/yyyy'; dataRow.getCell(4).numFmt = rupiahFormat; dataRow.getCell(5).numFmt = rupiahFormat; dataRow.getCell(6).numFmt = rupiahFormat;
      dataRow.getCell(6).style.font = { bold: true }; dataRow.getCell(6).style.alignment = { horizontal: 'right' };
      dataRow.getCell(4).style.alignment = { horizontal: 'right' }; dataRow.getCell(5).style.alignment = { horizontal: 'right' };
      
      // Highlight baris margin
      if (item.isMargin) {
        dataRow.getCell(4).style.font = { bold: true, color: { argb: 'FF27AE60' } }; // Uang Masuk Margin Hijau Bold
        dataRow.eachCell(cell => {
          if (!cell.style.fill) { cell.style.fill = {}; } // Inisialisasi jika belum ada
          cell.style.fill.type = 'pattern';
          cell.style.fill.pattern = 'solid';
          cell.style.fill.fgColor = { argb: 'FFE6F2FF' }; // Biru muda
        });
      }
      currentRow++;
    });

    // Baris Total
    worksheet.addRow([]);
    const totalRow = worksheet.addRow(['', '', 'TOTAL PERIODE', totalMasuk, totalKeluar, '', '']);
    totalRow.getCell(3).style = totalStyle; totalRow.getCell(4).style = totalStyle; totalRow.getCell(4).numFmt = rupiahFormat;
    totalRow.getCell(5).style = totalStyle; totalRow.getCell(5).numFmt = rupiahFormat;
    totalRow.getCell(4).font = { bold: true, color: { argb: 'FF27AE60' } }; totalRow.getCell(5).font = { bold: true, color: { argb: 'FFE74C3C' } };

    // Atur Lebar Kolom & Print Setup
    worksheet.columns = [ { key: 'A', width: 12 }, { key: 'B', width: 10 }, { key: 'C', width: 35 }, { key: 'D', width: 18 }, { key: 'E', width: 18 }, { key: 'F', width: 18 }, { key: 'G', width: 30 } ];
    worksheet.pageSetup.orientation = 'landscape'; worksheet.pageSetup.fitToPage = true; worksheet.pageSetup.fitToWidth = 1; worksheet.pageSetup.fitToHeight = 0;

    // Set Header & Tulis ke response
    const fileName = `Buku_Margin_${startDate}_sd_${endDate}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
    await workbook.xlsx.write(res);
    res.end();

  } catch (error) { console.error('Error exporting Margin to Excel:', error); res.status(500).send('Gagal mengekspor Buku Margin'); }
};