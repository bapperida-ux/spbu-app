// src/controllers/transaksiKasController.js
const TransaksiKas = require('../models/transaksiKasModel');

// Membuat Transaksi Kas Baru
exports.createTransaksiKas = async (req, res) => {
  try {
    const { kodeKas, tanggal, total, keterangan } = req.body;
    const newTransaksi = new TransaksiKas({ kodeKas, tanggal, total, keterangan });
    await newTransaksi.save();
    res.status(201).json(newTransaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Mendapatkan Semua Transaksi Kas (HANYA HARI INI)
exports.getAllTransaksiKas = async (req, res) => {
  try {
    // Tentukan awal dan akhir hari ini
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date();
    end.setHours(23, 59, 59, 999);

    const allTransaksi = await TransaksiKas.find({
      tanggal: { $gte: start, $lte: end }
    }).sort({ createdAt: -1 }); // Urutkan dari yg terbaru
    res.json(allTransaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// --- FUNGSI BARU UNTUK EDIT/DELETE ---

// Mendapatkan 1 Transaksi by ID
exports.getTransaksiKasById = async (req, res) => {
  try {
    const { id } = req.params;
    const transaksi = await TransaksiKas.findById(id);
    if (!transaksi) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(transaksi);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Mengupdate 1 Transaksi by ID
exports.updateTransaksiKas = async (req, res) => {
  try {
    const { id } = req.params;
    const { kodeKas, tanggal, total, keterangan } = req.body;

    const updated = await TransaksiKas.findByIdAndUpdate(
      id,
      { kodeKas, tanggal, total, keterangan },
      { new: true, runValidators: true }
    );
    if (!updated) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Menghapus 1 Transaksi by ID
exports.deleteTransaksiKas = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await TransaksiKas.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json({ message: 'Transaksi berhasil dihapus', id: deleted._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};