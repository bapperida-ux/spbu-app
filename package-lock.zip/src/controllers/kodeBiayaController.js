// src/controllers/kodeBiayaController.js
const KodeBiaya = require('../models/kodeBiayaModel');

// 1. Membuat Kode Biaya Baru
exports.createKodeBiaya = async (req, res) => {
  try {
    const { kode, uraian, jenis } = req.body;
    const existing = await KodeBiaya.findOne({ kode });
    if (existing) {
      return res.status(400).json({ error: 'Kode biaya sudah ada. Tidak boleh duplikat.' });
    }
    const newKodeBiaya = new KodeBiaya({ kode, uraian, jenis });
    await newKodeBiaya.save();
    res.status(201).json(newKodeBiaya);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 2. Mendapatkan Semua Kode Biaya
exports.getAllKodeBiaya = async (req, res) => {
  try {
    const allKodeBiaya = await KodeBiaya.find({}).sort({ kode: 1 });
    res.json(allKodeBiaya);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 3. Menghapus Kode Biaya
exports.deleteKodeBiaya = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await KodeBiaya.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json({ message: 'Data berhasil dihapus', id: deleted._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. MENDAPATKAN 1 KODE BIAYA BY ID (BARU)
exports.getKodeBiayaById = async (req, res) => {
  try {
    const { id } = req.params;
    const kodeBiaya = await KodeBiaya.findById(id);
    if (!kodeBiaya) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(kodeBiaya); // Kirim data spesifik
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 5. MENGUPDATE 1 KODE BIAYA BY ID (BARU)
exports.updateKodeBiaya = async (req, res) => {
  try {
    const { id } = req.params;
    const { kode, uraian, jenis } = req.body;

    // Cek duplikasi kode (pastikan kode baru tidak dipakai oleh data LAIN)
    const existing = await KodeBiaya.findOne({ kode: kode, _id: { $ne: id } });
    if (existing) {
      return res.status(400).json({ error: 'Kode biaya tersebut sudah dipakai data lain.' });
    }

    const updatedKodeBiaya = await KodeBiaya.findByIdAndUpdate(
      id,
      { kode, uraian, jenis },
      { new: true, runValidators: true }
    );

    if (!updatedKodeBiaya) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
    res.json(updatedKodeBiaya); // Kirim data yang sudah di-update
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};