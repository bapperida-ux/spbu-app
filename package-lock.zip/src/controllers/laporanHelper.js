// src/controllers/laporanHelper.js
// Logika yang dipindahkan dari laporanController.js dan exportController.js

const TransaksiKas = require('../models/transaksiKasModel');
const TransaksiBiaya = require('../models/transaksiBiayaModel');
const KodeKas = require('../models/kodeKasModel');
const KodeBiaya = require('../models/kodeBiayaModel');

async function getKodeMap(model) {
  const items = await model.find({});
  const map = new Map();
  items.forEach(item => map.set(item.kode, { uraian: item.uraian, jenis: item.jenis }));
  return map;
}

async function calculateSaldoAwal(startDate) {
  let saldo = 0;
  const kodeKasMap = await getKodeMap(KodeKas);
  const kodeBiayaMap = await getKodeMap(KodeBiaya);

  const startOfDay = new Date(startDate);
  startOfDay.setHours(0, 0, 0, 0); // Pastikan mulai dari awal hari

  const kasSebelum = await TransaksiKas.find({ tanggal: { $lt: startOfDay } });
  kasSebelum.forEach(trx => {
    const detailKode = kodeKasMap.get(trx.kodeKas);
    if (detailKode) {
      if (detailKode.jenis === 'Penambah') saldo += trx.total;
      else if (detailKode.jenis === 'Pengurang' || detailKode.jenis === 'Pindahan') saldo -= trx.total;
    }
  });

  const biayaSebelum = await TransaksiBiaya.find({ tanggal: { $lt: startOfDay } });
  biayaSebelum.forEach(trx => {
    const detailKode = kodeBiayaMap.get(trx.kodeBiaya);
    if (detailKode) {
      if (detailKode.jenis === 'Penambah') saldo += trx.total;
      else saldo -= trx.total;
    }
  });
  return saldo;
}

// Fungsi untuk mengambil data Laporan Kas (untuk controller & export)
async function getLaporanKasData(startDate, endDate) {
  const start = new Date(startDate);
  start.setHours(0,0,0,0); // Mulai awal hari
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999); // Akhir hari

  const saldoAwal = await calculateSaldoAwal(start);
  const kodeKasMap = await getKodeMap(KodeKas);

  const transaksi = await TransaksiKas.find({
    tanggal: { $gte: start, $lte: end }
  }).sort({ tanggal: 1, createdAt: 1 });

  const laporanData = transaksi.map(trx => {
    const detailKode = kodeKasMap.get(trx.kodeKas);
    return {
      _id: trx._id, tanggal: trx.tanggal, kode: trx.kodeKas,
      uraian: detailKode ? detailKode.uraian : 'Kode Tidak Ditemukan',
      jenis: detailKode ? detailKode.jenis : 'Unknown',
      total: trx.total, keterangan: trx.keterangan,
    };
  });
  return { saldoAwal, data: laporanData };
}

// Fungsi untuk mengambil data Laporan Biaya
async function getLaporanBiayaData(startDate, endDate) {
  const start = new Date(startDate);
  start.setHours(0,0,0,0);
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);

  const saldoAwal = await calculateSaldoAwal(start); // Saldo awal sama
  const kodeBiayaMap = await getKodeMap(KodeBiaya);

  const transaksi = await TransaksiBiaya.find({
    tanggal: { $gte: start, $lte: end }
  }).sort({ tanggal: 1, createdAt: 1 });

  const laporanData = transaksi.map(trx => {
    const detailKode = kodeBiayaMap.get(trx.kodeBiaya);
    return {
      _id: trx._id, tanggal: trx.tanggal, kode: trx.kodeBiaya,
      uraian: detailKode ? detailKode.uraian : 'Kode Tidak Ditemukan',
      jenis: detailKode ? detailKode.jenis : 'Unknown',
      total: trx.total, keterangan: trx.keterangan,
    };
  });
  return { saldoAwal, data: laporanData };
}

// Fungsi untuk mengambil data Laporan Margin
async function getLaporanMarginData(startDate, endDate) {
  const start = new Date(startDate);
  start.setHours(0,0,0,0);
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);

  const kodeKasMap = await getKodeMap(KodeKas);
  const kodeBiayaMap = await getKodeMap(KodeBiaya);

  const transactionsBiayaAll = await TransaksiBiaya.find({
      tanggal: { $gte: start, $lte: end }
  });
  const transactionsKasAll = await TransaksiKas.find({
      tanggal: { $gte: start, $lte: end }
  });

  const processedBiaya = transactionsBiayaAll
    .filter(tx => {
      const detailKode = kodeBiayaMap.get(tx.kodeBiaya);
      const uraianLower = detailKode ? String(detailKode.uraian).trim().toLowerCase() : "";
      return uraianLower !== 'isi kas';
    })
    .map(tx => {
        const detailKode = kodeBiayaMap.get(tx.kodeBiaya);
        const jenis = detailKode ? detailKode.jenis : 'Unknown';
        return {
            tanggal: tx.tanggal, kode: tx.kodeBiaya,
            uraian: detailKode ? detailKode.uraian : 'Kode Biaya Tdk Ditemukan',
            uangMasuk: jenis === 'Penambah' ? tx.total : 0,
            uangKeluar: jenis === 'Pengurang' || jenis === 'Pindahan' ? tx.total : 0,
            keterangan: tx.keterangan || '', isMargin: false
        };
    });

  const processedMargin = transactionsKasAll
    .filter(tx => {
        const detailKode = kodeKasMap.get(tx.kodeKas);
        const uraianLower = detailKode ? String(detailKode.uraian).trim().toLowerCase() : "";
        return uraianLower === 'margin';
    })
    .map(tx => ({
        tanggal: tx.tanggal, kode: tx.kodeKas, uraian: 'Margin Harian',
        uangMasuk: tx.total, uangKeluar: 0,
        keterangan: tx.keterangan || '', isMargin: true
    }));

  const combinedData = [...processedBiaya, ...processedMargin];
  combinedData.sort((a, b) => {
      const dateA = new Date(a.tanggal); const dateB = new Date(b.tanggal);
      const dateComparison = dateA - dateB;
      if (dateComparison !== 0) return dateComparison;
      if (a.isMargin && !b.isMargin) return 1;
      if (!a.isMargin && b.isMargin) return -1;
      return 0;
  });

  // Saldo Awal untuk Margin selalu 0
  return { saldoAwal: 0, data: combinedData };
}


// Ekspor semua fungsi helper
module.exports = {
  getLaporanKasData,
  getLaporanBiayaData,
  getLaporanMarginData
};