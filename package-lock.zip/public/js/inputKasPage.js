// public/js/inputKasPage.js
import Choices from 'https://esm.sh/choices.js';

export class InputKasPage {
  constructor(apiService, notificationService) {
    this.api = apiService;
    this.notification = notificationService;
    
    // Elemen Halaman
    this.form = document.getElementById('form-input-kas');
    this.formTitle = document.getElementById('form-input-kas-title');
    this.kodeKasSelect = document.getElementById('input-kas-kode');
    this.tanggalInput = document.getElementById('input-kas-tanggal');
    this.totalInput = document.getElementById('input-kas-total');
    this.keteranganInput = document.getElementById('input-kas-keterangan');
    this.batalBtn = this.form.querySelector('.btn-batal');
    this.simpanBtn = this.form.querySelector('.btn-simpan');
    this.tableBody = document.getElementById('tabel-input-kas-body');

    // Inisialisasi Choices.js
    this.choicesKas = new Choices(this.kodeKasSelect, {
      searchEnabled: true,
      itemSelectText: 'Pilih',
      placeholder: true,
      placeholderValue: '-- Pilih Kode Kas --',
    });
    
    // State
    this.editingId = null;
    this.kodeKasMap = new Map(); // Untuk menyimpan 'kode' -> 'uraian'
  }

  init() {
    this._populateDropdown(); // Panggil ini dulu
    this._loadTable(); // Baru panggil ini
    this._setupEventListeners();
    this._setDefaultDate();
  }

  async _populateDropdown() {
    try {
      const kodeKasData = await this.api.get('/api/kodekas');
      const formattedData = kodeKasData.map(item => {
        // Simpan ke map untuk dipakai di tabel
        this.kodeKasMap.set(item.kode, item.uraian); 
        return {
          value: item.kode,
          label: `${item.kode} - ${item.uraian}`
        };
      });
      this.choicesKas.setChoices(formattedData, 'value', 'label', true);
    } catch (error) {
      this.notification.show('Gagal memuat data master Kode Kas', 'error');
    }
  }

  _setupEventListeners() {
    this.form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this._handleSubmit();
    });
    
    this.batalBtn.addEventListener('click', () => this._resetForm());
    
    // Listener untuk tabel
    this.tableBody.addEventListener('click', async (e) => {
      const editButton = e.target.closest('.action-btn.edit');
      const deleteButton = e.target.closest('.action-btn.delete');

      if (editButton) {
        const id = editButton.getAttribute('data-id');
        await this._handleEditClick(id);
      } else if (deleteButton) {
        const id = deleteButton.getAttribute('data-id');
        await this._handleDelete(id);
      }
    });
  }
  
  _setDefaultDate() {
    // Set tanggal hari ini
    const today = new Date().toISOString().split('T')[0];
    this.tanggalInput.value = today;
  }

  _resetForm() {
    this.form.reset();
    this.choicesKas.clearInput();
    this.choicesKas.setChoiceByValue('');
    this._setDefaultDate();
    
    // Reset mode edit
    this.editingId = null;
    this.simpanBtn.innerText = 'Simpan Transaksi';
    this.formTitle.innerText = 'Formulir Input Kas';
    this.form.parentElement.classList.remove('editing');
  }

  // Memuat data tabel
  async _loadTable() {
    try {
      const transaksiData = await this.api.get('/api/transaksikas');
      this.tableBody.innerHTML = ''; // Kosongkan tabel
      
      for (const trx of transaksiData) {
        this.tableBody.appendChild(this._createRow(trx));
      }
    } catch (error) {
      this.notification.show('Gagal memuat data transaksi', 'error');
    }
  }
  
  // Membuat 1 baris <tr>
  _createRow(trx) {
    const row = document.createElement('tr');
    // Ambil uraian dari map
    const uraian = this.kodeKasMap.get(trx.kodeKas) || 'Kode Tidak Dikenal';
    
    // Format tanggal
    const tanggal = new Date(trx.tanggal).toLocaleDateString('id-ID', {
      day: '2-digit', month: '2-digit', year: 'numeric'
    });
    
    row.innerHTML = `
      <td>${tanggal}</td>
      <td>${trx.kodeKas} - ${uraian}</td>
      <td>${trx.keterangan || ''}</td>
      <td>${trx.total.toLocaleString('id-ID')}</td>
      <td>
        <button class="action-btn edit" data-id="${trx._id}">✏️</button>
        <button class="action-btn delete" data-id="${trx._id}">🗑️</button>
      </td>
    `;
    return row;
  }
  
  // Klik Edit
  async _handleEditClick(id) {
    try {
      const trx = await this.api.get(`/api/transaksikas/${id}`);
      
      // Format tanggal YYYY-MM-DD
      const tgl = new Date(trx.tanggal).toISOString().split('T')[0];
      
      this.tanggalInput.value = tgl;
      this.totalInput.value = trx.total;
      this.keteranganInput.value = trx.keterangan;
      this.choicesKas.setChoiceByValue(trx.kodeKas); // Set dropdown
      
      this.editingId = id;
      this.simpanBtn.innerText = 'Update Transaksi';
      this.formTitle.innerText = 'Edit Transaksi Kas';
      this.form.parentElement.classList.add('editing'); // Highlight form
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      this.notification.show('Gagal mengambil data untuk diedit', 'error');
    }
  }
  
  // Klik Delete
  async _handleDelete(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) return;
    
    try {
      await this.api.delete(`/api/transaksikas/${id}`);
      this.notification.show('Transaksi berhasil dihapus', 'success');
      await this._loadTable();
      this._resetForm(); // Reset form jika data yg diedit dihapus
    } catch (error) {
      this.notification.show(`Error: ${error.message}`, 'error');
    }
  }
  
  // Submit Form (Create atau Update)
  async _handleSubmit() {
    const data = {
      kodeKas: this.kodeKasSelect.value,
      tanggal: this.tanggalInput.value,
      total: this.totalInput.value,
      keterangan: this.keteranganInput.value
    };

    if (!data.kodeKas) {
      this.notification.show('Kode Kas harus dipilih', 'error');
      return;
    }

    try {
      if (this.editingId) {
        // --- UPDATE DATA ---
        await this.api.put(`/api/transaksikas/${this.editingId}`, data);
        this.notification.show('Transaksi kas berhasil di-update!', 'success');
      } else {
        // --- BUAT DATA BARU ---
        await this.api.post('/api/transaksikas', data);
        this.notification.show('Transaksi kas berhasil disimpan!', 'success');
      }
      this._resetForm();
      await this._loadTable(); // Muat ulang tabel
    } catch (error) {
      this.notification.show(`Error: ${error.message}`, 'error');
    }
  }
}