// public/js/bukuMarginPage.js

export class BukuMarginPage {
  constructor(apiService, notificationService) {
    this.api = apiService;
    this.notification = notificationService;
    
    // Elemen Filter & Tombol
    this.startDateInput = document.getElementById('margin-start-date');
    this.endDateInput = document.getElementById('margin-end-date');
    this.filterBtn = document.getElementById('margin-filter-btn');
    this.exportBtn = document.getElementById('margin-export-excel-btn'); 
    
    // Elemen Tabel
    this.tableBody = document.getElementById('tabel-laporan-margin-body');
    this.totalMasukEl = document.getElementById('margin-total-masuk');
    this.totalKeluarEl = document.getElementById('margin-total-keluar');
  }

  init() {
    this._setDefaultDates();
    this._setupEventListeners();
    this.fetchAndDisplayReport(); 
  }
  
  // === PASTIKAN FUNGSI INI ADA ===
  _formatRupiah(number) {
    // Handle null, undefined, atau non-numeric values gracefully
    if (number === null || number === undefined || isNaN(Number(number))) {
        return 'Rp 0'; // Atau tampilkan '-' atau pesan error sesuai kebutuhan
    }
    const absValue = Math.abs(Number(number)); 
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', currency: 'IDR',
      minimumFractionDigits: 0, maximumFractionDigits: 0
    }).format(absValue); 
  }
  
  // === PASTIKAN FUNGSI INI ADA ===
  _formatTanggal(dateString) {
     if (!dateString) return '';
     try {
       const date = new Date(dateString);
       // Check if date is valid
       if (isNaN(date.getTime())) return 'Invalid Date'; 
       return date.toLocaleDateString('id-ID', {
         day: '2-digit', month: '2-digit', year: 'numeric'
       });
     } catch (e) {
       console.error("Error formatting date:", dateString, e);
       return 'Invalid Date';
     }
  }
  // ===============================

  _setDefaultDates() {
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
    this.startDateInput.value = firstDay;
    this.endDateInput.value = lastDay;
  }

  _setupEventListeners() {
    // --- PASTIKAN TOMBOL FILTER BENAR ---
    if (this.filterBtn) {
        this.filterBtn.addEventListener('click', () => {
            console.log("Tombol Tampilkan diklik!"); // Debugging
            this.fetchAndDisplayReport();
        });
    } else {
        console.error("Tombol filter 'margin-filter-btn' tidak ditemukan.");
    }

    // --- LISTENER TOMBOL EKSPOR EXCEL ---
    if (this.exportBtn) { 
        this.exportBtn.addEventListener('click', () => {
            console.log("Tombol Ekspor diklik!"); // Debugging
            this._handleExportExcel(); 
        });
    } else {
        console.error("Tombol ekspor 'margin-export-excel-btn' tidak ditemukan.");
    }
  }

  async fetchAndDisplayReport() {
    console.log("Memulai fetchAndDisplayReport..."); // Debugging
    const startDate = this.startDateInput.value;
    const endDate = this.endDateInput.value;

    if (!startDate || !endDate || startDate > endDate) {
      this.notification.show('Filter tanggal tidak valid', 'error');
      console.error("Filter tanggal tidak valid:", startDate, endDate); // Debugging
      return;
    }

    this.tableBody.innerHTML = '<tr><td colspan="7">Memuat data...</td></tr>';
    
    try {
      // --- PASTIKAN ENDPOINT BENAR ---
      console.log(`Memanggil API: /api/laporan/margin?startDate=${startDate}&endDate=${endDate}`); // Debugging
      const response = await this.api.get(`/api/laporan/margin?startDate=${startDate}&endDate=${endDate}`);
      console.log("Respon API diterima:", response); // Debugging
      
      // Pastikan response.data ada dan merupakan array
      if (!response || !Array.isArray(response.data)) {
           throw new Error("Format respon API tidak valid atau data tidak ditemukan.");
      }
      const { data } = response; // Saldo awal dihitung di frontend
      
      this.tableBody.innerHTML = ''; 
      let currentSaldo = 0.0; let totalMasukPeriode = 0.0; let totalKeluarPeriode = 0.0;

      const saldoAwalRow = document.createElement('tr'); saldoAwalRow.classList.add('saldo-awal-row'); saldoAwalRow.innerHTML = `<td colspan="5">SALDO AWAL PERIODE</td><td class="text-right text-bold">${this._formatRupiah(0)}</td><td></td>`; this.tableBody.appendChild(saldoAwalRow);

      if (data.length === 0) {
        this.tableBody.innerHTML += '<tr><td colspan="7">Tidak ada data untuk rentang tanggal ini.</td></tr>';
      } else {
        data.forEach((item, index) => { // Tambahkan index untuk debugging
            console.log(`Processing item ${index}:`, item); // Debugging
            let uangMasuk = 0; let uangKeluar = 0; let saldoChange = 0;
            // Pastikan item.uangMasuk dan item.uangKeluar adalah angka
            const itemUangMasuk = Number(item.uangMasuk) || 0;
            const itemUangKeluar = Number(item.uangKeluar) || 0;

            if (item.isMargin) { 
                uangMasuk = itemUangMasuk; 
                saldoChange = itemUangMasuk; 
                totalMasukPeriode += itemUangMasuk; 
            } else { 
                if (itemUangMasuk > 0) { 
                    uangMasuk = itemUangMasuk; 
                    saldoChange = itemUangMasuk; 
                    totalMasukPeriode += itemUangMasuk; 
                } 
                if (itemUangKeluar > 0) { 
                    uangKeluar = itemUangKeluar; 
                    saldoChange = -itemUangKeluar; 
                    totalKeluarPeriode += itemUangKeluar; 
                } 
            }
            currentSaldo += saldoChange;
            const row = document.createElement('tr'); if (item.isMargin) row.classList.add('margin-row');
            const displayUangMasuk = uangMasuk > 0 ? this._formatRupiah(uangMasuk) : '-'; 
            const displayUangKeluar = uangKeluar > 0 ? `- ${this._formatRupiah(uangKeluar)}` : '-'; 
            // Pastikan currentSaldo adalah angka sebelum diformat
            const displaySaldo = this._formatRupiah(currentSaldo); 
            
            row.innerHTML = `<td>${this._formatTanggal(item.tanggal)}</td><td>${item.kode || ''}</td><td>${item.uraian || ''}</td><td class="text-right ${uangMasuk > 0 ? (item.isMargin ? 'text-success text-bold' : 'text-success') : ''}">${displayUangMasuk}</td><td class="text-right ${uangKeluar > 0 ? 'text-danger' : ''}">${displayUangKeluar}</td><td class="text-right text-bold">${currentSaldo < 0 ? `- ${displaySaldo}` : displaySaldo}</td><td>${item.keterangan || ''}</td>`;
            this.tableBody.appendChild(row);
        });
      }
      this.totalMasukEl.innerText = this._formatRupiah(totalMasukPeriode);
      this.totalKeluarEl.innerText = `- ${this._formatRupiah(totalKeluarPeriode)}`;
      console.log("Render tabel selesai."); // Debugging
    } catch (error) {
      this.notification.show('Gagal memuat laporan margin', 'error');
      console.error("Error di fetchAndDisplayReport Buku Margin:", error);
      this.tableBody.innerHTML = `<tr><td colspan="7" style="color:red;">Gagal memuat data: ${error.message}</td></tr>`;
      this.totalMasukEl.innerText = this._formatRupiah(0);
      this.totalKeluarEl.innerText = `- ${this._formatRupiah(0)}`;
    }
  }
  
  _handleExportExcel() {
    console.log("Memulai _handleExportExcel..."); // Debugging
    const startDate = this.startDateInput.value;
    const endDate = this.endDateInput.value;

    if (!startDate || !endDate) {
      this.notification.show('Pilih tanggal filter terlebih dahulu', 'error');
      console.error("Tanggal filter kosong saat ekspor."); // Debugging
      return;
    }
    
    const apiUrl = `/api/export/margin?startDate=${startDate}&endDate=${endDate}`;
    console.log("Mengarahkan ke URL ekspor:", apiUrl); // Debugging
    window.location.href = apiUrl; 
    this.notification.show('Mempersiapkan file Excel...', 'success', 2000);
  }
}