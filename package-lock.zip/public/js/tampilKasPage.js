// public/js/tampilKasPage.js

export class TampilKasPage {
  constructor(apiService, notificationService) {
    this.api = apiService;
    this.notification = notificationService;
    
    // Elemen Filter
    this.startDateInput = document.getElementById('kas-start-date');
    this.endDateInput = document.getElementById('kas-end-date');
    this.filterBtn = document.getElementById('kas-filter-btn');
    // --- AMBIL TOMBOL EKSPOR ---
    this.exportBtn = document.getElementById('kas-export-btn'); 
    
    // Elemen Tabel
    this.tableBody = document.getElementById('tabel-laporan-kas-body');
    this.totalMasukEl = document.getElementById('kas-total-masuk');
    this.totalKeluarEl = document.getElementById('kas-total-keluar');
  }

  init() {
    this._setDefaultDates();
    this._setupEventListeners();
    this.fetchAndDisplayReport(); 
  }
  
  _formatRupiah(number) {
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', currency: 'IDR',
      minimumFractionDigits: 0, maximumFractionDigits: 0
    }).format(Math.abs(number));
  }
  
  _formatTanggal(dateString) {
     const date = new Date(dateString);
     return date.toLocaleDateString('id-ID', {
       day: '2-digit', month: '2-digit', year: 'numeric'
     });
  }

  _setDefaultDates() {
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
    this.startDateInput.value = firstDay;
    this.endDateInput.value = lastDay;
  }

  _setupEventListeners() {
    this.filterBtn.addEventListener('click', () => {
      this.fetchAndDisplayReport();
    });
    // --- TAMBAHKAN LISTENER EKSPOR ---
    if (this.exportBtn) { // Cek jika tombol ditemukan
        this.exportBtn.addEventListener('click', () => {
            this._handleExport();
        });
    } else {
        console.error("Tombol ekspor 'kas-export-btn' tidak ditemukan di HTML.");
    }
  }

  async fetchAndDisplayReport() {
    const startDate = this.startDateInput.value;
    const endDate = this.endDateInput.value;

    if (!startDate || !endDate || startDate > endDate) {
      this.notification.show('Filter tanggal tidak valid.', 'error');
      return;
    }

    try {
      const response = await this.api.get(`/api/laporan/kas?startDate=${startDate}&endDate=${endDate}`);
      const { saldoAwal, data } = response;
      
      this.tableBody.innerHTML = ''; 
      let currentSaldo = saldoAwal;
      let totalMasukPeriode = 0;
      let totalKeluarPeriode = 0;

      const saldoAwalRow = document.createElement('tr'); saldoAwalRow.classList.add('saldo-awal-row'); saldoAwalRow.innerHTML = `<td colspan="5">SALDO AWAL</td><td>${this._formatRupiah(currentSaldo)}</td><td>Saldo sebelum ${this._formatTanggal(startDate)}</td>`; this.tableBody.appendChild(saldoAwalRow);

      data.forEach(trx => {
        let uangMasuk = 0; let uangKeluar = 0;
        if (trx.jenis === 'Penambah') { uangMasuk = trx.total; currentSaldo += trx.total; totalMasukPeriode += trx.total; } 
        else if (trx.jenis === 'Pengurang' || trx.jenis === 'Pindahan') { uangKeluar = trx.total; currentSaldo -= trx.total; totalKeluarPeriode += trx.total; }
        const row = document.createElement('tr');
        row.innerHTML = `<td>${this._formatTanggal(trx.tanggal)}</td><td>${trx.kode}</td><td>${trx.uraian}</td><td class="uang-masuk">${uangMasuk > 0 ? this._formatRupiah(uangMasuk) : '-'}</td><td class="uang-keluar">${uangKeluar > 0 ? `- ${this._formatRupiah(uangKeluar)}` : '-'}</td><td>${this._formatRupiah(currentSaldo)}</td><td>${trx.keterangan || ''}</td>`;
        this.tableBody.appendChild(row);
      });
      
      this.totalMasukEl.innerText = this._formatRupiah(totalMasukPeriode);
      this.totalKeluarEl.innerText = `- ${this._formatRupiah(totalKeluarPeriode)}`;

    } catch (error) {
      this.notification.show('Gagal memuat laporan kas', 'error');
      console.error(error);
    }
  }
  
  // --- FUNGSI EKSPOR EXCEL ---
  _handleExport() {
    const startDate = this.startDateInput.value;
    const endDate = this.endDateInput.value;

    if (!startDate || !endDate) {
      this.notification.show('Pilih tanggal filter terlebih dahulu', 'error');
      return;
    }
    
    const apiUrl = `/api/export/kas?startDate=${startDate}&endDate=${endDate}`;
    window.location.href = apiUrl; 
    this.notification.show('Mempersiapkan file Excel...', 'success', 2000);
  }
}