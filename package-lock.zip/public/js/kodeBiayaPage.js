// public/js/kodeBiayaPage.js

export class KodeBiayaPage {
  constructor(apiService, notificationService) {
    this.api = apiService;
    this.notification = notificationService;
    
    // --- PERUBAHAN DI SINI ---
    this.formContainer = document.querySelector('#input-kode-biaya .form-container'); 
    this.form = document.getElementById('form-kode-biaya');
    this.formTitle = this.formContainer.querySelector('h3');
    // --- AKHIR PERUBAHAN ---
    
    this.kodeInput = document.getElementById('kode-biaya-kode');
    this.uraianInput = document.getElementById('kode-biaya-uraian');
    this.jenisInput = document.getElementById('kode-biaya-jenis');
    this.simpanBtn = this.form.querySelector('.btn-simpan');
    this.batalBtn = this.form.querySelector('.btn-batal');
    
    this.tableBody = document.getElementById('tabel-kode-biaya-body');
    
    this.editingId = null;
    this.originalTitle = this.formTitle.innerText; // Simpan judul asli
  }

  init() {
    this._loadTable();
    this._setupEventListeners();
  }

  _setupEventListeners() {
    // Saat formulir disubmit (tombol Simpan/Update)
    this.form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this._handleSubmitForm();
    });

    // Saat tombol Batal diklik
    this.batalBtn.addEventListener('click', () => {
      this._resetForm();
    });

    // Menggunakan 'closest()' agar lebih kuat
    this.tableBody.addEventListener('click', async (e) => {
      // Cek tombol edit
      const editButton = e.target.closest('.action-btn.edit');
      if (editButton) {
        e.preventDefault();
        const id = editButton.getAttribute('data-id');
        await this._handleEditClick(id);
        return; // Hentikan eksekusi
      }

      // Cek tombol delete
      const deleteButton = e.target.closest('.action-btn.delete');
      if (deleteButton) {
        e.preventDefault();
        const id = deleteButton.getAttribute('data-id');
        await this._handleDelete(id);
        return;
      }
    });
  }

  // Mengosongkan formulir dan mereset state
  _resetForm() {
    this.form.reset();
    this.editingId = null;
    
    // --- PERUBAHAN DI SINI ---
    this.simpanBtn.innerText = 'Simpan';
    this.formContainer.classList.remove('editing'); // Hapus class highlight
    this.formTitle.innerText = this.originalTitle; // Kembalikan judul
    // --- AKHIR PERUBAHAN ---
  }

  // Memuat data tabel
  async _loadTable() {
    try {
      const data = await this.api.get('/api/kodebiaya');
      this.tableBody.innerHTML = ''; 
      data.forEach(item => {
        this.tableBody.appendChild(this._createRow(item));
      });
    } catch (error) {
      console.error('Gagal memuat tabel kode biaya:', error);
      this.notification.show('Gagal memuat data tabel.', 'error');
    }
  }

  // Dipanggil saat tombol ✏️ diklik
  async _handleEditClick(id) {
    try {
      const data = await this.api.get(`/api/kodebiaya/${id}`);
      
      this.kodeInput.value = data.kode;
      this.uraianInput.value = data.uraian;
      this.jenisInput.value = data.jenis;
      
      this.editingId = data._id;

      // --- PERUBAHAN DI SINI ---
      this.simpanBtn.innerText = 'Update';
      this.formContainer.classList.add('editing'); // Tambah class highlight
      this.formTitle.innerText = 'Edit Kode Biaya'; // Ubah judul
      // --- AKHIR PERUBAHAN ---
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
    } catch (error) {
      this.notification.show(`Error: ${error.message}`, 'error');
    }
  }

  // Menangani Simpan (Create) dan Update
  async _handleSubmitForm() {
    const data = {
      kode: this.kodeInput.value,
      uraian: this.uraianInput.value,
      jenis: this.jenisInput.value,
    };

    try {
      if (this.editingId) {
        await this.api.put(`/api/kodebiaya/${this.editingId}`, data);
        this.notification.show('Kode Biaya berhasil di-update!', 'success');
      } else {
        await this.api.post('/api/kodebiaya', data);
        this.notification.show('Kode Biaya berhasil disimpan!', 'success');
      }
      this._resetForm();
      await this._loadTable();
    } catch (error) {
      this.notification.show(`Error: ${error.message}`, 'error');
    }
  }

  async _handleDelete(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus Kode Biaya ini?')) {
      return;
    }
    
    try {
      await this.api.delete(`/api/kodebiaya/${id}`);
      this.notification.show('Kode Biaya berhasil dihapus.', 'success');
      await this._loadTable();

      // Jika data yg sedang diedit dihapus, reset form
      if (id === this.editingId) {
        this._resetForm();
      }
    } catch (error) {
      this.notification.show(`Gagal menghapus Kode Biaya: ${error.message}`, 'error');
    }
  }

  _createRow(item) {
    const row = document.createElement('tr');
    const badgeClass = `badge badge-${item.jenis.toLowerCase().replace(/\s/g, '-')}`;
    row.innerHTML = `
      <td>${item.kode}</td>
      <td>${item.uraian}</td>
      <td><span class="${badgeClass}">${item.jenis}</span></td>
      <td>
        <button class="action-btn edit" data-id="${item._id}">✏️</button>
        <button class="action-btn delete" data-id="${item._id}">🗑️</button>
      </td>
    `;
    return row;
  }
}